
import React, { createContext, useContext, useState, useEffect } from 'react';
import { SKU, ABCClass, XYZClass } from '../types';
import { MOCK_SKUS } from '../constants';

interface DataContextType {
  skus: SKU[];
  importData: (file: File) => Promise<void>;
  resetData: () => void;
  isLoading: boolean;
  updateSku: (id: string, updates: Partial<SKU>) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [skus, setSkus] = useState<SKU[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem('ap_planning_data');
    if (saved) {
      try {
        setSkus(JSON.parse(saved));
      } catch (e) {
        setSkus(MOCK_SKUS);
      }
    } else {
      setSkus(MOCK_SKUS);
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('ap_planning_data', JSON.stringify(skus));
    }
  }, [skus, isLoading]);

  const importData = async (file: File) => {
    setIsLoading(true);
    // Simulación de procesamiento de IA para limpieza de datos
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Aquí iría la lógica real de parsing CSV. Por ahora simulamos una actualización
    const reader = new FileReader();
    reader.onload = (e) => {
      // En una app real, parsearíamos e.target.result (CSV)
      // Para el ejemplo, "importamos" clonando y alterando levemente para notar el cambio
      const newData = skus.map(s => ({
        ...s,
        stockLevel: Math.floor(s.stockLevel * (0.8 + Math.random() * 0.4)),
        alerts: Math.random() > 0.8 ? ['Data Updated'] : s.alerts
      }));
      setSkus(newData);
      setIsLoading(false);
    };
    reader.readAsText(file);
  };

  const resetData = () => {
    setSkus(MOCK_SKUS);
    localStorage.removeItem('ap_planning_data');
  };

  const updateSku = (id: string, updates: Partial<SKU>) => {
    setSkus(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
  };

  return (
    <DataContext.Provider value={{ skus, importData, resetData, isLoading, updateSku }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within DataProvider');
  return context;
};
