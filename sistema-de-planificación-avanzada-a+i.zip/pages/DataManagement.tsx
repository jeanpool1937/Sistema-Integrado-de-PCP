
import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';

export const DataManagement: React.FC = () => {
  const { skus, importData, resetData, isLoading } = useData();
  const [dragActive, setDragActive] = useState(false);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      importData(e.target.files[0]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Status Card */}
        <div className="bg-dark-900 border border-slate-800 rounded-xl p-6">
          <h3 className="text-lg font-bold text-white mb-4">Estado de la Base de Datos</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Total SKUs</span>
              <span className="text-white font-mono font-bold">{skus.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Última Sincronización</span>
              <span className="text-slate-300 text-sm">Hace 2 mins</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Salud de Datos</span>
              <div className="flex items-center gap-2">
                <div className="w-24 h-2 bg-slate-800 rounded-full overflow-hidden">
                  <div className="bg-primary-500 h-full w-[92%]"></div>
                </div>
                <span className="text-primary-500 font-bold text-xs">92%</span>
              </div>
            </div>
            <button 
              onClick={resetData}
              className="w-full mt-4 text-xs text-red-400 hover:text-red-300 border border-red-500/20 hover:border-red-500/50 p-2 rounded transition-all"
            >
              Reiniciar Base de Datos (MOCK)
            </button>
          </div>
        </div>

        {/* Import Zone */}
        <div className="lg:col-span-2">
          <div 
            className={`h-full border-2 border-dashed rounded-xl flex flex-col items-center justify-center p-8 transition-all ${
              dragActive ? 'border-primary-500 bg-primary-500/5' : 'border-slate-800 bg-dark-900'
            }`}
            onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
            onDragLeave={() => setDragActive(false)}
            onDrop={(e) => { e.preventDefault(); setDragActive(false); }}
          >
            {isLoading ? (
              <div className="flex flex-col items-center gap-4">
                <div className="w-12 h-12 border-4 border-primary-600 border-t-transparent rounded-full animate-spin"></div>
                <p className="text-white font-medium">Procesando con IA Planning Engine...</p>
                <p className="text-slate-400 text-xs text-center">Limpiando outliers y validando coherencia histórica</p>
              </div>
            ) : (
              <>
                <div className="w-16 h-16 bg-primary-600/10 rounded-full flex items-center justify-center mb-4 text-primary-500">
                  <span className="material-symbols-rounded text-4xl">upload_file</span>
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Importar Data Histórica</h3>
                <p className="text-slate-400 text-sm text-center mb-6 max-w-sm">
                  Arrastra tu archivo CSV o Excel aquí para actualizar niveles de stock, demanda histórica y parámetros de lead time.
                </p>
                <input 
                  type="file" 
                  id="file-upload" 
                  className="hidden" 
                  accept=".csv,.json"
                  onChange={handleFile}
                />
                <label 
                  htmlFor="file-upload" 
                  className="bg-primary-600 hover:bg-primary-500 text-white px-8 py-3 rounded-lg font-bold cursor-pointer transition-colors flex items-center gap-2"
                >
                  <span className="material-symbols-rounded">cloud_upload</span>
                  Seleccionar Archivo
                </label>
                <p className="mt-4 text-[10px] text-slate-500 uppercase tracking-widest font-bold">Formatos soportados: CSV, JSON, XLSX</p>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Raw Data Preview */}
      <div className="bg-dark-900 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-slate-800 flex justify-between items-center">
          <h3 className="text-lg font-bold text-white">Explorador de Registros Brutos</h3>
          <div className="flex gap-2">
            <div className="relative">
              <span className="material-symbols-rounded absolute left-3 top-2.5 text-slate-500 text-sm">search</span>
              <input 
                type="text" 
                placeholder="Buscar en DB..." 
                className="bg-slate-800 border-none rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:ring-1 focus:ring-primary-500"
              />
            </div>
          </div>
        </div>
        <div className="overflow-x-auto h-[400px]">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="sticky top-0 bg-dark-900 z-10 border-b border-slate-800">
              <tr className="text-slate-500 uppercase font-bold">
                <th className="p-4">SKU ID</th>
                <th className="p-4">Categoría</th>
                <th className="p-4 text-right">Stock</th>
                <th className="p-4">Hist (M-1)</th>
                <th className="p-4">Hist (M-2)</th>
                <th className="p-4">Hist (M-3)</th>
                <th className="p-4">Lead Time</th>
                <th className="p-4">Costo</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-400">
              {skus.slice(0, 50).map(s => (
                <tr key={s.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="p-4 font-mono text-primary-400">{s.id}</td>
                  <td className="p-4">{s.category}</td>
                  <td className="p-4 text-right">{s.stockLevel}</td>
                  <td className="p-4">{s.history[5]}</td>
                  <td className="p-4">{s.history[4]}</td>
                  <td className="p-4">{s.history[3]}</td>
                  <td className="p-4">{s.leadTime}d</td>
                  <td className="p-4">${s.cost}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-4 bg-slate-900/50 text-center border-t border-slate-800">
          <span className="text-xs text-slate-500">Mostrando primeros 50 de {skus.length} registros</span>
        </div>
      </div>
    </div>
  );
};
