
import React from 'react';
import { StatCard } from '../components/StatCard';
import { useData } from '../contexts/DataContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardProps {
  onViewChange: (view: any) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onViewChange }) => {
  const { skus } = useData();
  
  const criticalStock = skus.filter(s => s.stockLevel < s.safetyStock).length;
  const excessStock = skus.filter(s => s.stockLevel > s.rop * 1.5).length;
  const totalValue = skus.reduce((acc, s) => acc + (s.stockLevel * s.cost), 0);

  // Health data from current skus
  const inventoryHealth = [
    { name: 'Crítico', value: criticalStock, fill: '#ef4444' },
    { name: 'Advertencia', value: Math.floor(skus.length * 0.1), fill: '#f59e0b' },
    { name: 'Saludable', value: skus.length - criticalStock - excessStock - Math.floor(skus.length * 0.1), fill: '#22c55e' },
    { name: 'Exceso', value: excessStock, fill: '#3b82f6' },
  ];

  return (
    <div className="space-y-6">
      {/* KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Nivel de Servicio Global" 
          value="94.2%" 
          trend="+1.2%" 
          trendUp={true} 
          icon="verified"
          color="bg-indigo-600"
        />
        <StatCard 
          title="Valor Inventario" 
          value={`$${(totalValue / 1000000).toFixed(2)}M`} 
          trend="-0.5%" 
          trendUp={true} 
          icon="payments"
          color="bg-emerald-600"
        />
        <StatCard 
          title="SKUs Críticos" 
          value={criticalStock.toString()} 
          trend={`Actualizado`} 
          trendUp={criticalStock < 100} 
          icon="warning"
          color="bg-red-600"
        />
        <StatCard 
          title="Precisión Pronóstico" 
          value="88.5%" 
          trend="+2.1%" 
          trendUp={true} 
          icon="insights"
          color="bg-blue-600"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart Section */}
        <div className="lg:col-span-2 bg-dark-900 border border-slate-800 rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
            Salud del Inventario (Real-Time DB)
            <span className="text-xs bg-slate-800 px-2 py-1 rounded-full text-slate-400 font-normal">{skus.length} SKUs activos</span>
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={inventoryHealth} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={false} />
                <XAxis type="number" stroke="#94a3b8" />
                <YAxis dataKey="name" type="category" width={100} stroke="#94a3b8" />
                <Tooltip 
                  cursor={{fill: '#1e293b'}}
                  contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '8px' }}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Actions / Alerts */}
        <div className="bg-dark-900 border border-slate-800 rounded-xl p-6 overflow-hidden flex flex-col">
          <h3 className="text-lg font-semibold text-white mb-4">Alertas de Base de Datos</h3>
          <div className="space-y-3 flex-1">
            {skus.filter(s => s.stockLevel < s.safetyStock).slice(0, 5).map(sku => (
              <div key={sku.id} className="flex items-center justify-between p-3 bg-red-500/10 border border-red-500/20 rounded-lg group hover:bg-red-500/20 transition-all">
                <div className="flex items-center gap-3">
                  <span className="material-symbols-rounded text-red-500">priority_high</span>
                  <div>
                    <p className="text-sm font-medium text-white">{sku.id}</p>
                    <p className="text-xs text-red-300">Nivel Crítico: {sku.stockLevel}u</p>
                  </div>
                </div>
                <button className="text-[10px] bg-red-600/50 group-hover:bg-red-600 text-white px-2 py-1 rounded transition-colors uppercase font-bold">
                  Reponer
                </button>
              </div>
            ))}
            {criticalStock === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-slate-500">
                <span className="material-symbols-rounded text-4xl mb-2">check_circle</span>
                <p>No hay quiebres detectados</p>
              </div>
            )}
          </div>
          <button 
            onClick={() => onViewChange('inventory')}
            className="w-full text-center text-xs text-slate-500 hover:text-white mt-4 pt-4 border-t border-slate-800 transition-colors"
          >
            Ver auditoría completa de stock &rarr;
          </button>
        </div>
      </div>
    </div>
  );
};
